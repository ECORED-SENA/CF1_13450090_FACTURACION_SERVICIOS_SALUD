function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5fuhWccGMt6":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

